
/*

Wap to demostrate array of object.

Employee : 
empid, ename


*/

#include<iostream>
using namespace std;

const int size=3;

class Employee
{
		int emp_id;
		string ename;
		
		public : 
				void getdata();
				void putdata(); 

};

void Employee :: getdata()
{
	cout<<"\n\n\t Employee's Id : ";
	cin>>emp_id;
	cout<<"\n\n\t Employee's name  : ";
	cin>>ename;
}

void Employee :: putdata()
{
	cout<<"\n\n\t ................................";
	cout<<"\n\n\t Employee's Id : "<<emp_id;
	cout<<"\n\n\t Employee's name  : "<<ename;
}

main()
{
	int size=30;
	
	cout<<"\n\n\t Input how many employee's data you want to add : ";
	cin>>size;
	
	Employee E[size];
	
	for(int i=0;i<size;i++)
	{
		E[i].getdata();
	}
	
	for(int i=0;i<size;i++)
	{
		E[i].putdata();
	}
		
}
	

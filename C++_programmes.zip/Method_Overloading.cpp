//To demostrate Method Overloading.

#include<iostream>
using namespace std;

class Sum
{
	int n1, n2;
	double n3, n4;
	int n5, n6, n7;
	
	public :
			void add(int a, int b)
			{
				n1=a;
				n2=b;		
			}
			
			void add(double c, double d)
			{
				n3=c;
				n4=d;	
			}
			
			void add(int e, int f, int g)
			{
				n5=e;
				n6=f;
				n7=g;	
			}
			
			void printdata()
			{
				cout<<"\n\n\t n1 + n2 = "<<n1+n2;
				cout<<"\n\n\t n3 + n4 = "<<n3+n4;
				cout<<"\n\n\t n5 + n6 + n7 = "<<n5+n6+n7;
			}
				
};

main()
{
	int a, b;
	double c, d;
	int e, f, g;
	
	a=10;
	b=20;
	
	c=1.5;
	d=8.9;
	
	e=30;
	f=40;
	g=50;
	
	Sum S;
	S.add(a,b); // calculate integer values.
	S.add(c, d); //calculate double values.
	S.add(e,f,g); //calculate float values
	
	S.printdata();
}

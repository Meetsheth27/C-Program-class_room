
#include<iostream>
using namespace std;

class Car
{
	string company;
	string model;
	int year;
	
	public :
			Car()  //default cons.
			{
			}
			
			Car(string com, string mod, int y) //parameterized cons.
			{
				company=com;
				model=mod;
				year=y;
			}
			
			Car (Car &obj) //copy constructor. to copy one obj from another.
			{
				company=obj.company;
				model=obj.model;
				year=obj.year;
			}
			
			void setvalues()
			{
				cout<<"\n\n\t About Car ...............................";
				cout<<"\n\n\t Company Name  : "<<company;
				cout<<"\n\n\t Car Model : "<<model;
				cout<<"\n\n\t Year : "<<year;
			}
					
};

main()
{
	Car C("Hyndai","SS122", 2019);
	Car C1;
	C1=C; //copy con
	C.setvalues();
	C1.setvalues();
	
}


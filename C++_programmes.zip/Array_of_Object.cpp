/*

Wap to demostrate array of object.

Employee : 
empid, ename


*/

#include<iostream>
using namespace std;

class Employee
{
		int emp_id;
		string ename;
		
		public : 
				void getdata();
				void putdata(); 

};

void Employee :: getdata()
{
	cout<<"\n\n\t Employee's Id : ";
	cin>>emp_id;
	cout<<"\n\n\t Employee's name  : ";
	cin>>ename;
}

void Employee :: putdata()
{
	cout<<"\n\n\t ................................";
	cout<<"\n\n\t Employee's Id : "<<emp_id;
	cout<<"\n\n\t Employee's name  : "<<ename;
}

main()
{
	Employee E[3];
	
	for(int i=0;i<3;i++)
	{
		E[i].getdata();
	}
	
	for(int i=0;i<3;i++)
	{
		E[i].putdata();
	}
		
}

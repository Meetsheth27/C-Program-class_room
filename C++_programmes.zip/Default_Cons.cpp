/*

Default constructor is used to initialize the data member of the class.
It is invoked automatically when we are creating the object of class Student.

*/

#include<iostream>
using namespace std;

class Student
{
	int rollno;
	string name;
	
	public : 
	
			Student() //default constructor.
			{
				rollno=101;
				name="xyz";
			}
	
			void printdata()
			{
				cout<<"\n\n\t Rollno : "<<rollno;
				cout<<"\n\n\t Name  : "<<name;
			}
};

main()
{
	Student S; //call default constructor auto.
	
	S.printdata();
}



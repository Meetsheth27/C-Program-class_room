//To demostrate the single Inheritance. (private  derivation)


#include<iostream>
using namespace std;

class Base
{
	int b;  //private
	
	public : 
			void get_base()
			{
				b=10;
				cout<<"\n\n\t b = "<<b;
			}
};

class Derive : private Base
{
	int d; //private
	
	public :
			void get_derive()
			{
				get_base(); //private access
				
				d=60;
				cout<<"\n\n\t d = "<<d;
			}
};

main()
{
	Derive Dobj;
	
	
	Dobj.get_derive();
}

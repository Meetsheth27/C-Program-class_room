//Multilevel Inheritance
//Grand Father > Father > child

#include<iostream>
using namespace std;

class A
{
	int a;
	
	public : void printdata_A()
			{
				a=10;
				cout<<"\n\n\t A = "<<a;	
			}	
};

class B : public A
{
	int b;
	
	public : void printdata_B()
			{
				b=20;
				cout<<"\n\n\t B = "<<b;	
			}		
};

class C : public B
{
	int c;
	
	public : void printdata_C()
			{
				c=30;
				cout<<"\n\n\t C = "<<c;	
			}		
};

main()
{
	C cobj;
	
	cobj.printdata_A();
	cobj.printdata_B();
	cobj.printdata_C();
}


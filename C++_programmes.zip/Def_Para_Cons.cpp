
#include<iostream>
using namespace std;

class Even
{
	int range, count;
	
	public :
			/*Even()
			{
				count=0;
			}*/
			
			Even(int r)
			{
				range=r;
			}
			
			void displayEven()
			{
				count=0;
				for(int i=2;i<=range;i=i+2)
				{
					cout<<"\n\n\t Even No : "<<i;
					count++;	
				}
				
				cout<<"\n\n\t Total Even numbers are : "<<count;
			}
	
		
};

main()
{
	Even E(20);
	
	E.displayEven();
	
	
}


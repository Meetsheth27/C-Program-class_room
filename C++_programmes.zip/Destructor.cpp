

#include<iostream>
using namespace std;

class Sample
{
	public :
			Sample()
			{
				cout<<"\n\n\t Constructor is called...";	
			}
			
			~Sample() //destructor
			{
					cout<<"\n\n\t Destructor is called...";
			}
					
};

main()
{
	Sample S;
}

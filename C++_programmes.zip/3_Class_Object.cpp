/*
Wap to demostrate the class & object.

class : student

Data members : 	s_id
				s_name
				marks

Member Function :   getvalue()	
					setvalue()


*/

#include<iostream>   //iostream is a class.
#include<string.h>
using namespace std;

class Student
{
	private :
	int s_id;
	char s_name[30];
	int marks;
	
	public :
			void getvalue()  //To initioalize the data members of the class.
			{
					s_id=101;
					strcpy(s_name, "virat");
					marks=88;
			} 
	
			void setvalue()
			{
				cout<<"\n\n\t Student' id  : "<<s_id;
				cout<<"\n\n\t Student's name : "<<s_name;
				cout<<"\n\n\t Marks : "<<marks;
			}
	
		
};

main()
{
	Student sobj; //to create an object for "Student" class.
	
	sobj.getvalue();
	sobj.setvalue();
}




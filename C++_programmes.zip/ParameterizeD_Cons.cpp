

#include<iostream>
using namespace std;

class Sum
{
	int n1, n2;
	
	public :
				Sum(int a, int b) 
				{
					n1=a;
					n2=b;
				}
				
				void display()
				{
					cout<<"\n\n\t n1  = "<<n1;
					cout<<"\n\n\t n2 = "<<n2;
				}
		
};

main()
{
	Sum S1(10, 5); 
	
	S1.display();
}

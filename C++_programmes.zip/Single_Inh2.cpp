//To demostrate the single Inheritance. (protected  derivation)

#include<iostream>
using namespace std;

class Base
{
	private : int a;  //accessible only for this class.
	
	protected : int b; //Accessible for derive class also
	
	public :  int c;  //Accessible for derive class & main (out side the class)
				
			 int get_pri()
			{
				a=10;
				return a;
			}	
};

class Derive : protected Base 
{
	public :
		
		int get_pro()
		{
			b=20;
			return b;
		}
		
		int get_pub()
		{
			c=30;
		
			cout<<"\n\n\t Private Data Member  : "<<get_pri();
			return c;
		}
};

main()
{
	Derive D;
	
	//cout<<"\n\n\t Private Data Member a = "<<D.get_pri();
	cout<<"\n\n\t Protected Data Member b = "<<D.get_pro();
	cout<<"\n\n\t Public Data Member c = "<<D.get_pub();
}

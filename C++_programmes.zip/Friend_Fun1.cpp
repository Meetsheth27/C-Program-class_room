/*
friend function : it is not a member function of the class so can not be invoked by . operator.
You have to pass the object as an argument to access the private member of the class.

friend function is used to access private data member.
*/

#include<iostream>
using namespace std;

class Math
{
	int n;  //private data member of the class 
	
	friend void cube(Math M) //in private part
	{
		cout<<"\n\n\t Cube : "<<M.n*M.n*M.n;			
	}
	
	public : 
	
			void getdata(int num)  //member function/method
			{
				n=num;	
			}
			
			friend void square(Math M) //in public part (it is not a member function)
			{
				cout<<"\n\n\t Square : "<<M.n*M.n;			
			}

			
};

main()
{
		Math M;
		int n;
		cout<<"\n\n\t Input a number : ";
		cin>>n;
		M.getdata(n);
		square(M);
		cube(M);
		
		
}

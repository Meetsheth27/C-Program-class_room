

#include<iostream>
using namespace std;

class Sum
{
	int n1, n2;
	
	public :
				Sum() 
				{ 
				
				}
				
				Sum(Sum &S) 
				{
					n1=S.n1;
					n2=S.n2;
				}
				
				void getdata()
				{
					cout<<"\n\n\t Number 1  : ";
					cin>>n1;
					cout<<"\n\n\t Number 2  : ";
					cin>>n2;
				}
				void display()
				{
					cout<<"\n\n\t -----------------";
					cout<<"\n\n\t n1  = "<<n1;
					cout<<"\n\n\t n2 = "<<n2;
				}
		
};

main()
{
	Sum S1; // call default cons
	S1.getdata(); //s1 object initialized
	S1.display(); // values printed
	
	Sum S2; //call default cons
	S2=S1; //call copy constructor s1 will be copied to s2
	
	S2.display();
}

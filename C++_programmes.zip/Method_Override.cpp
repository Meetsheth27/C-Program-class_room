//Method overriding

#include<iostream>
using namespace std;

class Base
{
	public :
			void print()
			{
				cout<<"\n\n\t Base class called...";
			}
};

class Derived : public Base
{
	public :
			void print()
			{
				cout<<"\n\n\t Derived class called...";
			}
};

main()
{
	Derived D;
	
	D.print();
	D.Base :: print();
	
}


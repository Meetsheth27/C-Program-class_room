/*
Wap to demostrate addition of two values.
*/

#include<iostream>   //iostream is a class.
using namespace std;

main()
{
	int n1, n2;
	
	cout<<"\n\n\t Input a number1 : ";
	cin>>n1;
	
	cout<<"\n\n\t Input a number2 : ";
	cin>>n2;
	
	//cout<<"\n\n\t Addition : "<<n1+n2;
	
	cout<<endl<<endl<<"addition : "<<n1+n2;
	
}

#include<iostream>
using namespace std;

class A
{
	public : 
			A()
			{
				cout<<"\n\n\t Constructor called from A...";	
			}	
};

class B
{
	public :
			B()
			{
				cout<<"\n\n\t Constructor called from B...";
			}	
};

class C : public A, public B
{
		public :
				C()
				{
					cout<<"\n\n\t Constructor called from C...";	
				}
};

main()
{
	C cobj;
	
	
}


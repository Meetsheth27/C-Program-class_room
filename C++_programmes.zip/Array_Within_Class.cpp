/*Wap to demostrate the marksheet as score card of student. (using array within class)

rollno
Student name
marks (5)
total
Per


*/

#include<iostream>
using namespace std;

class Student
{
	int rollno;
	string sname;
	int marks[5];
	float per;
	
	public : 
			void getdata();
			void putdata();
	
};

void Student :: getdata()
{
	cout<<"\n\n\t Input Rollno : ";
	cin>>rollno;
	cout<<"\n\n\t Input Student's name : ";
	cin>>sname;
	
	for(int i=0;i<5;i++)
	{
		cout<<"\n\n\t Input array ["<<i<<"] : ";
		cin>>marks[i];
		
	}
	
}

void Student :: putdata()
{
	int total;
	cout<<"\n\n\t .............................";
	cout<<"\n\n\t Rollno : "<<rollno;
	cout<<"\n\n\t Name : "<<sname;
	
	for(int i=0;i<5;i++)
	{
		cout<<"\n\n\t Marks ["<<i<<"] : "<<marks[i]; 
		total=total+marks[i];
	}
	per=total/5;
	cout<<"\n\n\t .............................";
	cout<<"\n\n\t Total : "<<total;
	cout<<"\n\n\t Percentage : "<<per;
	
}

main()
{
	Student S;
	S.getdata();
	S.putdata();
}

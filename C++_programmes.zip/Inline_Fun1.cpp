/* Inline Function.

Inline function is used for one liner code to reduce complexity to indicate to the compiler.
This function can not include any conditional or looping statements.

Program to do : 
Wap to make mathematical operations addition, subtraction, multiplication, division for 
two numbers using inline functions. 

*/

#include<iostream>
using namespace std;

class Math
{
	int n;
	
	public : 
	
			void getdata(int num)
			{
				n=num;	
			}
			
			inline int square() //one liner function
			{
				return n*n;
				//cout<<"\n\n\t square : "<<n*n;
			}
			
			inline int cube()
			{
				return n*n*n;
			}
};

main()
{
		Math M;
		
		int s, c, num;
		
		cout<<"\n\n\t Input a number  : ";
		cin>>num;
		M.getdata(num);
		
		s=M.square();
		cout<<"\n\n\t Square : "<<s;
		
		c=M.cube();
		cout<<"\n\n\t Cube : "<<c;
}

#include<iostream>
using namespace std;

class Student
{
	int stud_id;
	string sname;
	
	public :
			Student()
			{
				stud_id=111;
				sname="Virat";
			}
			
			void print_stud_data()
			{
				cout<<"\n\n\t Student's Details... ";
				cout<<"\n\n\t Stud Id : "<<stud_id;
				cout<<"\n\n\t Name : "<<sname;
			}	
};

class Personal : public Student
{
	string city;
	int age;
	
	public : 
			Personal()
			{
					city="Ahmedabad";
					age=36;
			}
			
			void print_personal_data()
			{
				cout<<"\n\n\t Personal Details... ";
				cout<<"\n\n\t City : "<<city;
				cout<<"\n\n\t Age : "<<age;
			}	
};

class Course : public Personal
{
		string course;
		int fees;
		
		public : 
				Course()
				{
					course="SE";
					fees=30000;
				}
				void print_course_data()
				{
						cout<<"\n\n\t Course Details... ";
						cout<<"\n\n\t Course : "<<course;
						cout<<"\n\n\t Fees : "<<fees;
				}	
		
};

main()
{
	Course Cobj; //default call constructor for derive class & its base class.
	
	Cobj.print_stud_data();
	Cobj.print_personal_data();
	Cobj.print_course_data();
	
}





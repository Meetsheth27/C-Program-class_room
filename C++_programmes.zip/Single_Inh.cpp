//To demostrate the single Inheritance. (public derivation)


#include<iostream>
using namespace std;

class Base
{
	int b;  //private
	
	public : 
			void get_base()
			{
				b=10;
				cout<<"\n\n\t b = "<<b;
			}
};

class Derive : public Base
{
	int d; //private
	
	public :
	void get_derive()
			{
				d=60;
				cout<<"\n\n\t d = "<<d;
			}
};

main()
{
	Derive Dobj;
	
	Dobj.get_base(); //public inherited mode
	Dobj.get_derive();
}

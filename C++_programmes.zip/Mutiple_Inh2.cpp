#include<iostream>
using namespace std;

class Trainer
{
	string t_name;
	
	public :
			Trainer()
			{
				t_name="chinmayee";
			}
			
			void print_trainer()
			{
				cout<<"\n\n\t Trainer's Name : "<<t_name;
			}
			
};

class Course
{
	string c_name;
	
	public :
			Course()
			{
				c_name="SE";
			}
			
			void print_course()
			{
				cout<<"\n\n\t Course's Name : "<<c_name;
			}
	
};

class TopsTech : public Trainer, public Course
{
	int duration;
	
	public :
				TopsTech()
				{
					duration=4;	
				}
				
				void print_duration()
				{
					cout<<"\n\n\t Total duration in Tops  : "<<duration;
				}
	
};

main()
{
		TopsTech TT;
		TT.print_trainer();
		TT.print_course();
		TT.print_duration();
		
		
}
